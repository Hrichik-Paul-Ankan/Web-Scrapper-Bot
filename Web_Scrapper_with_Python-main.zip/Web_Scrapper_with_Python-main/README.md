# Web_Scrapper_with_Python
This project is made by raw coding python to scrap any website just by giving their url 
